package com.example2.crude.dao;

import java.net.URI;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.example2.crude.domain.student;
import com.example2.crude.repository.repository;

@Repository
public class dao implements Studentdao  {

	@Autowired
	repository respo;
	
	@Override
	public List<student> getallStudents() {
		return respo.findAll();
		
	}

	@Override
	public void createstd(student std) {
		 respo.save(std);
	
	}

	public void delete(Long id) {
		respo.deleteById(id);
		
	}

	

}

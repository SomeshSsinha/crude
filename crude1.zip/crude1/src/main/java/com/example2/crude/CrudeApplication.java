package com.example2.crude;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudeApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudeApplication.class, args);
	}

}


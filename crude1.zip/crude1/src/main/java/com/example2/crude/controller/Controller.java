package com.example2.crude.controller;

import java.awt.PageAttributes.MediaType;
import java.util.List;

import javax.ws.rs.Produces;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example2.crude.domain.student;
import com.example2.crude.service.StudenService;
import com.example2.crude.service.StudentService;

@RestController
public class Controller {

	@Autowired
	StudenService service;
	
	@GetMapping("/getall")
	@Produces(javax.ws.rs.core.MediaType.APPLICATION_JSON)
	public List<student> getallStudents()
	{
	 return service.getallStudents();
	}
	@Produces(javax.ws.rs.core.MediaType.APPLICATION_JSON)
	@PostMapping("/create")
	public void create(@RequestBody student std)
	{
		 service.createstd(std);
		
	}
	@Produces(javax.ws.rs.core.MediaType.APPLICATION_JSON)
	@DeleteMapping("/delete/{id}")
	public void delete(@PathVariable Long id )
	{
		service.delete(id);
	}
}

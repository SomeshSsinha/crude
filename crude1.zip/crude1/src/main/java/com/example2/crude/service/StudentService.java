package com.example2.crude.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example2.crude.dao.Studentdao;
import com.example2.crude.domain.student;

@Service
public class StudentService implements StudenService {

	@Autowired
	Studentdao dao;
	
	
	@Override
	public List<student> getallStudents() {
		return dao.getallStudents();
		
	}


	@Override
	public void createstd(student std) {
		 dao.createstd(std);
	}


	@Override
	public void delete(Long id) {
		dao.delete(id);
		
	}


	

}

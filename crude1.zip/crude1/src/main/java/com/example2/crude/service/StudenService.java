package com.example2.crude.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.example2.crude.domain.student;

public interface StudenService {

	List<student> getallStudents();

	

	void createstd(student std);



	void delete(Long id);

}
